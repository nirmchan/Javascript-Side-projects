// Inform the background page that
function getElementByXpath(path) {
  return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}
function gotomaintabanddotheaction(xpathval){
  //how to switch to the url first
    var targetelem=getElementByXpath(xpathval);
    $(targetelem).css({'border-color':'red'});
    $(targetelem).css({'border-style':'solid'});
}
// Listen for messages from the background
chrome.runtime.onMessage.addListener(function (msg, sender, response) {
  // First, validate the message's structure
  if ((msg.from === 'popup') && (msg.subject === 'userclicked')) {
    // Collect the necessary data
    // (For your specific requirements `document.querySelectorAll(...)`
    //  should be equivalent to jquery's `$(...)`)
    console.log("I am console js")
    gotomaintabanddotheaction(msg.xpath);
    // Directly respond to the sender (popup),
    // through the specified callback */
  //  response({farewell:"done"});
  }
});
